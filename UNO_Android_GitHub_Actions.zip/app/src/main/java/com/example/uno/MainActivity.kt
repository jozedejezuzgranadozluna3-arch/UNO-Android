package com.example.uno

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import kotlin.random.Random

data class Card(val color:Int,val value:Int) // 0-9,10 skip,11 reverse,12 +2,13 wild,14 +4

class MainActivity: Activity() {
    private val deck=mutableListOf<Card>()
    private val hands=Array(2){mutableListOf<Card>()}
    private val discard=mutableListOf<Card>()
    private var current=0
    private var chosenColor=0
    private var selected=0
    private lateinit var info:TextView
    private lateinit var cards:LinearLayout

    override fun onCreate(b:Bundle?){super.onCreate(b); newGame()}

    private fun newGame(){
        buildDeck(); hands.forEach{it.clear()}; discard.clear(); current=0; selected=0
        repeat(7){hands[0].add(deck.removeAt(deck.lastIndex));hands[1].add(deck.removeAt(deck.lastIndex))}
        var first=deck.removeAt(deck.lastIndex)
        while(first.value>=13){deck.add(0,first);first=deck.removeAt(deck.lastIndex)}
        discard.add(first); chosenColor=first.color
        render()
    }

    private fun buildDeck(){
        deck.clear()
        for(c in 0..3){
            deck.add(Card(c,0)); for(v in 1..9){repeat(2){deck.add(Card(c,v))}}
            repeat(2){deck.add(Card(c,10));deck.add(Card(c,11));deck.add(Card(c,12))}
        }
        repeat(4){deck.add(Card(4,13));deck.add(Card(4,14))}
        deck.shuffle(Random(System.currentTimeMillis()))
    }

    private fun playable(c:Card):Boolean{
        val top=discard.last()
        return c.color==4 || c.color==chosenColor || c.value==top.value
    }

    private fun drawFor(p:Int,n:Int=1){repeat(n){if(deck.isEmpty()) recycle(); if(deck.isNotEmpty()) hands[p].add(deck.removeAt(deck.lastIndex))}}

    private fun recycle(){
        if(discard.size<=1)return
        val top=discard.removeAt(discard.lastIndex)
        deck.addAll(discard); discard.clear(); discard.add(top); deck.shuffle(Random(System.currentTimeMillis()))
    }

    private fun play(i:Int){
        val h=hands[0]; if(i !in h.indices || !playable(h[i]))return
        val c=h.removeAt(i); discard.add(c); if(c.color==4) chooseColor()
        when(c.value){
            10->{current=1-current}
            11->{current=1-current} // 2-player reverse acts as skip
            12->{drawFor(1,2); current=1-current}
            14->{drawFor(1,4); current=1-current}
            else->current=1-current
        }
        if(h.isEmpty()){info.text="¡GANASTE! Pulsa NUEVA PARTIDA";cards.removeAllViews();return}
        aiTurn()
    }

    private fun chooseColor(){ chosenColor=(0..3).random() }

    private fun aiTurn(){
        val h=hands[1]; var idx=h.indexOfFirst{playable(it)}
        if(idx<0){drawFor(1); idx=h.indexOfFirst{playable(it)}}
        if(idx>=0){
            val c=h.removeAt(idx); discard.add(c); if(c.color==4) chosenColor=(0..3).random()
            when(c.value){10,11->current=0;12->{drawFor(0,2);current=0};14->{drawFor(0,4);current=0};else->current=0}
        } else current=0
        render()
    }

    private fun render(){
        val root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(16,16,16,16)
        val title=TextView(this);title.text="UNO";title.textSize=30f;title.gravity=Gravity.CENTER
        info=TextView(this);info.text="Tu turno • Cartas IA: ${hands[1].size}";info.textSize=18f;info.gravity=Gravity.CENTER
        val top=TextView(this);top.text="Descarte: ${name(discard.last())}";top.textSize=22f;top.gravity=Gravity.CENTER
        cards=LinearLayout(this);cards.orientation=LinearLayout.HORIZONTAL;cards.gravity=Gravity.CENTER
        for(i in hands[0].indices){
            val b=Button(this);b.text=name(hands[0][i]);b.setOnClickListener{play(i)};cards.addView(b,LinearLayout.LayoutParams(0,140,1f))
        }
        val draw=Button(this);draw.text="ROBAR";draw.setOnClickListener{drawFor(0);aiTurn()}
        val reset=Button(this);reset.text="NUEVA PARTIDA";reset.setOnClickListener{newGame()}
        root.addView(title);root.addView(info);root.addView(top);root.addView(cards);root.addView(draw);root.addView(reset)
        setContentView(root)
    }

    private fun name(c:Card)=when(c.color){0->"ROJO";1->"AMARILLO";2->"VERDE";3->"AZUL";else->"COMODÍN"}+" "+when(c.value){10->"SALTA";11->"REVERSA";12->"+2";13->"COMODÍN";14->"+4";else->c.value.toString()}
}
