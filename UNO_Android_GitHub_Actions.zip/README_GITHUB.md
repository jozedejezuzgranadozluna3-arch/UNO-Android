# UNO Android

Sube todo este proyecto a un repositorio de GitHub.

Luego:
1. Abre **Actions**.
2. Selecciona **Build UNO APK**.
3. Pulsa **Run workflow**.
4. Cuando termine, abre la ejecución.
5. En **Artifacts**, descarga **UNO-debug-apk**.
6. Extrae el ZIP y encontrarás `app-debug.apk`.
7. Instala ese APK en Android.

El workflow usa GitHub Actions + Gradle y publica el APK como artifact.
